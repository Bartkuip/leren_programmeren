playerLevel = 1
playerHealth = 150
goblinHealth = 10
orcHealth = 20
trollHealth = 35
gerlardHealth = 250
zombieHealth = 35
unknownHealth = 100