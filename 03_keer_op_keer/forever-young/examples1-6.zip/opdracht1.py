from RobotArm import RobotArm

robotArm = RobotArm('exercise 1')

# Jouw pyth
# on instructies zet je vanaf hier:


# Na jouw code wachten tot het sluiten van de window:
robotArm.moveRight()
robotArm.grab()
robotArm.moveLeft()
robotArm.drop()
robotArm.wait()